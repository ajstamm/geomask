## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(eval = TRUE, echo = FALSE,
  collapse = TRUE,
  comment = "#>"
)

## ----installtigris, eval = FALSE, echo = TRUE---------------------------------
#  # install tigris if necessary
#  install.packages("tigris")

## ----createshapefiles, eval = FALSE, echo = TRUE, warning = FALSE, message = FALSE----
#  # create and save the shapefiles
#  ot <- tigris::tracts("NY", "Onondaga", year = 2010)
#  ol <- tigris::landmarks("NY", "point", year = 2015)
#  t <- sf::st_contains(ot, ol) |> unlist()
#  ol <- ol[t, ]
#  
#  sf::write_sf(ot, dsn = "maps", layer = "onondaga_tracts", driver = "ESRI shapefile")
#  sf::write_sf(ol, dsn = "maps", layer = "onondaga_points", driver = "ESRI shapefile")
#  
#  rm(ol, ot, t)

## ----rungm, eval = FALSE, echo = TRUE, warning = FALSE, message = FALSE-------
#  geomask::runGMprogram()

## ----shppic, fig.cap = 'Dialog: Identify Location Shapefile', fig.alt = 'Dialog: Identify Location Shapefile', echo = FALSE----
# generate window for image
# uses gatpkg::locateGATshapefile()
knitr::include_graphics("images/locfile.png")

## ----locidpic, fig.cap = 'Dialog: Identify location ID variable', fig.alt = 'Dialog: Identify Location ID', echo = FALSE----
# generate window for image
# uses gatpkg::locateGATshapefile()
knitr::include_graphics("images/locid.png")

## ----boundpic, fig.cap = 'Dialog: Identify Boundary Shapefile', fig.alt = 'Dialog: Identify Boundary Shapefile', echo = FALSE----
# generate window for image
# uses gatpkg::locateGATshapefile()
knitr::include_graphics("images/boundfile.png")

## ----boundidpic, fig.cap = 'Dialog: Identify boundary ID variable', fig.alt = 'Dialog: Identify Boundary ID', echo = FALSE----
# generate window for image
# uses gatpkg::locateGATshapefile()
knitr::include_graphics("images/boundid.png")

## ----distpick, fig.cap = 'Dialog: Select Distances', fig.alt = 'Dialog: Select Distances', echo = FALSE----
# generate window for image
# geomask::selectGMdistance(step = 3, min = 100, max = 500, unit = "",
#                           quitopt = "Quit geomasker")
knitr::include_graphics("images/distselect.png")

## ----kmlpic, fig.cap = 'Dialog: Save KML', fig.alt = 'Dialog: Save KML', echo = FALSE----
# generate window for image
# gatpkg::saveGATkml(step = 9)
knitr::include_graphics("images/kmlpick.png")

## ----savepic, fig.cap = 'Dialog: Save File', fig.alt = 'Dialog: Save File', echo = FALSE----
# generate window for image
# gatpkg::saveGATfiles()
knitr::include_graphics("images/savefile.png")

## ----confirmpic, fig.cap = 'Dialog: Confirm Settings', fig.alt = 'Dialog: Confirm Settings', echo = FALSE----
knitr::include_graphics("images/confirmdialog.png")

## ----mapca, fig.show = "hold", fig.cap = 'Map: Compare original and shifted locations', echo = FALSE----
knitr::include_graphics("images/mapcompare.png")

## ----savesettings, eval=FALSE-------------------------------------------------
#  myfilepath <- "c:/users/my_id/my_folder/geomasked_points_settings.Rdata"
#  geomask::runGMprogram(settings = myfilepath)

## ----drawmap, eval = FALSE----------------------------------------------------
#  myfilepath <- "c:/users/my_id/my_folder" # wherever you saved the files
#  old <- sf::read_sf(dsn = myfilepath, layer = "geomasked_points_old")
#  new <- sf::read_sf(dsn = myfilepath, layer = "geomasked_points_new")
#  buffer <- sf::read_sf(dsn = myfilepath, layer = "geomasked_points_buffer")
#  
#  plot(sf::st_geometry(buffer[1:5,]), border = "green", col = rgb(0, 1, 0, .05))
#  plot(sf::st_geometry(old[1:5,]), add = TRUE, pch = 20, col = "blue")
#  plot(sf::st_geometry(new[1:5,]), add = TRUE, pch = 20, col = "red")

## ----endmessage, eval = FALSE, echo = TRUE, warning = FALSE, message = FALSE----
#  
#  > The following files have been written to the folder
#  > C:/Users/ajs11/Documents/GAT:
#  > Shapefile of new locations:
#  >   geomasked_points_new.dbf
#  >   geomasked_points_new.prj
#  >   geomasked_points_new.shp
#  >   geomasked_points_new.shx
#  > Shapefile of old locations:
#  >   geomasked_points_old.dbf
#  >   geomasked_points_old.prj
#  >   geomasked_points_old.shp
#  >   geomasked_points_old.shx
#  > Shapefile of buffers, for assessment:
#  >   geomasked_points_buffer.dbf
#  >   geomasked_points_buffer.prj
#  >   geomasked_points_buffer.shp
#  >   geomasked_points_buffer.shx
#  > Additional assessment and process files:
#  >   geomasked_points_map.pdf
#  >   geomasked_points.log
#  >   geomasked_points_settings.Rdata
#  >
#  > See the log file for more details.

